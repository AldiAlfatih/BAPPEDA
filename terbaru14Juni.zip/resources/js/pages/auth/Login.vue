<script setup lang="ts">
import InputError from '@/components/InputError.vue';
import TextLink from '@/components/TextLink.vue';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import AuthBase from '@/layouts/AuthLayout.vue';
import { Head, useForm } from '@inertiajs/vue3';
import { LoaderCircle } from 'lucide-vue-next';
import { onMounted } from 'vue';

defineProps<{
    status?: string;
    canResetPassword: boolean;
}>();

const form = useForm({
    email: '',
    password: '',
    remember: false as boolean,
});

const submit = () => {
    if (form.remember) {
        localStorage.setItem('remembered_email', form.email);
        localStorage.setItem('remembered_password', form.password);
    } else {
        localStorage.removeItem('remembered_email');
        localStorage.removeItem('remembered_password');
    }
    
    form.post(route('login'), {
        onFinish: () => form.reset('password'),
    });
};

// Check if we have remembered credentials when component mounts
onMounted(() => {
    // Try to get stored credentials from localStorage if remember was checked
    const rememberedEmail = localStorage.getItem('remembered_email');
    const rememberedPassword = localStorage.getItem('remembered_password');
    
    if (rememberedEmail && rememberedPassword) {
        form.email = rememberedEmail;
        form.password = rememberedPassword;
        form.remember = true;
    }
});
</script>

<template>
    <AuthBase title="Login">
        <Head title="Log in" />

        <div v-if="status" class="mb-4 text-center text-sm font-medium text-black">
            {{ status }}
        </div>
        
        <form @submit.prevent="submit" class="flex flex-col gap-6">
            <div class="grid gap-6">
                <div class="grid gap-2 text-black">
                    <Label for="email">Email address</Label>
                    <Input
                        id="email"
                        type="email"
                        required
                        autofocus
                        :tabindex="1"
                        autocomplete="email"
                        v-model="form.email"
                        placeholder="email@example.com"
                    />
                    <InputError :message="form.errors.email" />
                </div>

                <div class="grid gap-2 text-black">
                    <div class="flex items-center justify-between">
                        <Label for="password">Password</Label>
                    </div>
                    <Input
                        id="password"
                        type="password"
                        required
                        :tabindex="2"
                        autocomplete="current-password"
                        v-model="form.password"
                        placeholder="Password"
                    />
                    <InputError :message="form.errors.password" />
                </div>

                <div class="flex items-center justify-between">
                    <Label for="remember" class="flex items-center text-black ">
                        <Checkbox id="remember" v-model="form.remember"/>
                        <span>Remember me</span>
                    </Label>
                </div>

                <Button type="submit" class="w-full bg-green-900" :tabindex="4" :disabled="form.processing">
                    <LoaderCircle v-if="form.processing" class="h-4 w-4 animate-spin" />
                    Log in
                </Button>
            </div>
        </form>
    </AuthBase>
</template>